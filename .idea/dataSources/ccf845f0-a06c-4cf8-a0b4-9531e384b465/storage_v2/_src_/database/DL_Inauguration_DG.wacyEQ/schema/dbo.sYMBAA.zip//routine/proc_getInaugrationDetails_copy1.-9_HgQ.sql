CREATE PROCEDURE [dbo].[proc_getInaugrationDetails_copy1](
@id varchar(100)
)
as 
begin
--DL
select a.ID,IdentityNo,Name,case when Gender='1' then '男' else '女' end as Gender,BirthDay,
       case when Marriage='1' then '已婚' else '未婚' end as Marriage,
       case when Household='1' then '非農業' else '農業' end Household, 
       PhoneNumber,Province,Address,b.EduName as Education,School,
       case when Certificate='1' then '肄業' else '畢業' end Certificate,
       d.ApplyChannel,c.Propaganda,EntranceDate,GraduationDate
from dbo.Employee as a,Sys_Education as b  ,Sys_Propaganda c,Sys_ApplyChannel d
where a.ID=@id and a.Education=b.EduNo
--and a.ApplyChannel=d.ApplyChannelID and a.Propaganda=c.PropagandaID
and ISNULL(a.ApplyChannel,0) = ISNULL(d.ApplyChannelID,0) and ISNULL(a.Propaganda,0) =ISNULL(c.PropagandaID,0)


select Name,b.RelName as Relationship,Occupation,PhoneNumber,Address 
from dbo.Families as a,Sys_Relationship as b 
where ParentId=@id and a.Relationship=b.RelNo

select Name,b.RelName as Relationship,Department,PhoneNumber,EmpNo,Remark 
from dbo.RelativesInCompany as a,Sys_Relationship as b 
where ParentId=@id and a.Relationship=b.RelNo

select Name,b.RelName as Relationship,PhoneNumber,Address
from dbo.Linkman as a,Sys_Relationship as b  
where ParentId=@id and a.Relationship=b.RelNo

select Company,Occupation,ReasonForLeaving,Salary,EmploymentDate,ResignationDate 
from dbo.WorkExperience where ParentId=@id

select b.EmpNo From Employee as a ,HREntryForEmpNo as b where a.IdentityNo=b.IdentityNo
and a.ID=@id

SELECT
IdentityNo,
CASE
	WHEN IsVaccination = '1' THEN
	'是' ELSE '否' 
	END AS IsVaccination,
	dbo.func_vaccine_manufacturer_conversion ( Vaccination1 ) AS Vaccination1,
CASE
		WHEN datediff( DAY, cast( '1900-01-01' AS datetime ), Vaccination1Date ) = 0 THEN
		NULL ELSE Vaccination1Date 
	END AS Vaccination1Date,
	dbo.func_vaccine_manufacturer_conversion ( Vaccination2 ) AS Vaccination2,
CASE
		WHEN datediff( DAY, cast( '1900-01-01' AS datetime ), Vaccination2Date ) = 0 THEN
		NULL ELSE Vaccination2Date 
	END AS Vaccination2Date,
	Remark,
	UpdateTime 
FROM
Vaccine where ParentId=@id

--IDL

select IdentityNo,Name,EngName, Email,case when Gender='1' then '男' else '女' end as Gender,BirthDay,
       case when Marriage='1' then '已婚' else '未婚' end as Marriage,Nationality,Stature,Weight,
	   b.Language,c.LanguageLevel,
       PhoneNumber,Province,Address
from dbo.Employee_IDL  as a,Sys_Language as b,Sys_languageLevel as c
where a.ID=@id and a.Language=b.LanguageID  and a.Languagelevel=c.LanguageLevelID




select b.EduName as Education,School,Subject,EntranceDate,GraduationDate
From  Education_IDL as  a ,Sys_Education as b 
where ParentId=@id and a.Education=b.EduNo 


select Name,b.RelName as Relationship,Occupation,PhoneNumber,Address 
from dbo.Families_IDL as a,Sys_Relationship as b 
where ParentId=@id and a.Relationship=b.RelNo


select Name,Occupation,Address,PhoneNumber
from dbo.Friend_IDL 
where ParentId=@id 


select Name,b.RelName as Relationship,PhoneNumber,Address
from dbo.Linkman_IDL as a,Sys_Relationship as b  
where ParentId=@id and a.Relationship=b.RelNo


select Company,Job,Manager,Reason,Salary,EmploymentDate,ResignationDate 
from dbo.WorkExperience_IDL where ParentId=@id


select  Number,License,Unit,StartDate,EndDate,Hour
from  License_IDL where  ParentId=@id


select WorkExperience,Hobbies,Position,Salary 
from  ExpectWork_IDL  where ParentId=@id


select b.EmpNo From Employee_IDL as a ,HREntryForEmpNo as b where a.IdentityNo=b.IdentityNo
and a.ID=@id

SELECT
IdentityNo,
CASE
	WHEN IsVaccination = '1' THEN
	'是' ELSE '否' 
	END AS IsVaccination,
	dbo.func_vaccine_manufacturer_conversion ( Vaccination1 ) AS Vaccination1,
CASE
		WHEN datediff( DAY, cast( '1900-01-01' AS datetime ), Vaccination1Date ) = 0 THEN
		NULL ELSE Vaccination1Date 
	END AS Vaccination1Date,
	dbo.func_vaccine_manufacturer_conversion ( Vaccination2 ) AS Vaccination2,
CASE
		WHEN datediff( DAY, cast( '1900-01-01' AS datetime ), Vaccination2Date ) = 0 THEN
		NULL ELSE Vaccination2Date 
	END AS Vaccination2Date,
	Remark,
	UpdateTime 
FROM
Vaccine_IDL where ParentId=@id


end
go

