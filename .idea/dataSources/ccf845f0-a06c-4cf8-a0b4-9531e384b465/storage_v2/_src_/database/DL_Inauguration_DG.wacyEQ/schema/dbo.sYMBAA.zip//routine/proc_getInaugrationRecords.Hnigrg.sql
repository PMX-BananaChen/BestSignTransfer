CREATE procedure [dbo].[proc_getInaugrationRecords](
@idNo varchar(18),
@name nvarchar(20),
@startDate varchar(10),
@endDate varchar(10),
@area varchar(10),
@titleid varchar(10),
@CurrentPage int,
@pageSize int
)
as 
begin
declare @filter varchar(800)=''
declare @filterIDl varchar(800)=''
declare @sql varchar(3000)=''
if(@idNo!='')
begin
   set @filter=@filter+' and a.IdentityNo like ''%'+@idNo+'%'''
end
if(@name!='')
begin
   set @filter=@filter+' and Name like ''%'+@name+'%'''
end
if(@startDate!='')
begin
   set @filter=@filter+' and UpdateTime>='''+@startDate+' 00:00:00'''
end
if(@endDate!='')
begin
   set @filter=@filter+' and UpdateTime<='''+@endDate+' 23:59:59'''
end
if(@area!='')
begin
   set @filter=@filter+' and Area='''+@area+''''
end
if(@titleid!='')
begin
   set @filterIDl=@filter+' and TitleId='''+@titleid+''''
end

--DL
--UpdateTime 排序变更为empNo
set @sql='select a.*,b.EmpNo,row_number() over(partition by a.IdentityNo order by UpdateTime desc) as Rid into #t1 
from Employee a left join HREntryForEmpNo b on a.IdentityNo = b.IdentityNo where 1=1 '+@filter+CHAR(9)+CHAR(13)
set @sql=@sql+'select ID,IdentityNo,Name,case when Gender=''1'' then ''男'' else ''女'' end as Gender,BirthDay,case when Marriage=''1'' then ''已婚'' else ''未婚'' end as Marriage,case when Household=''1'' then ''非農業'' else ''農業'' end Household, 
PhoneNumber,Province,Address,UpdateTime,EmpNo,identity(int,1,1) as rowId into #t2 from #t1 where Rid=1 order by EmpNo desc'+CHAR(9)+CHAR(13)
set @sql=@sql+'select * from #t2 where rowId between '''+CAST((@CurrentPage-1)*@PageSize+1 as varchar)+''' and '''+CAST(@CurrentPage*@PageSize as varchar)+''''+CHAR(9)+CHAR(13)
set @sql=@sql+'select count(*) as TtlRecord,'''+CAST(@CurrentPage as varchar)+''' as CurrentPage,case when count(*)%'''+CAST(@PageSize as varchar)+'''=0 then count(*)/'''+CAST(@PageSize as varchar)+''' else (count(*)/'''+CAST(@PageSize as varchar)+''')+1 end as TtlPage from #t2'+CHAR(9)+CHAR(13)

--IDL
set @sql+=' select a.*,row_number() over(partition by a.IdentityNo order by UpdateTime desc) as Rid into #tIDL from Employee_IDL a where 1=1 '+ @filterIDl+CHAR(9)+CHAR(13)

--set @sql+=' select *,row_number() over(partition by IdentityNo order by UpdateTime desc) as Rid into #tIDL from Employee_IDL where 1=1 '+ @filter+CHAR(9)+CHAR(13)
set @sql=@sql+' select ID,IdentityNo,Name,case when Gender=''1'' then ''男'' else ''女'' end as Gender,BirthDay,
         case when Marriage=''1'' then ''已婚'' else ''未婚'' end as Marriage, 
         PhoneNumber,Province,Address,UpdateTime,identity(int,1,1) as rowId into #t2IDL from #tIDL where Rid=1 order by UpdateTime desc'+CHAR(9)+CHAR(13)
set @sql=@sql+' select * from #t2IDL where rowId between '''+CAST((@CurrentPage-1)*@PageSize+1 as varchar)+''' and '''+CAST(@CurrentPage*@PageSize as varchar)+''''+CHAR(9)+CHAR(13)
set @sql=@sql+' select count(*) as TtlRecord,'''+CAST(@CurrentPage as varchar)+''' as CurrentPage,case when count(*)%'''+CAST(@PageSize as varchar)+'''=0 then count(*)/'''+CAST(@PageSize as varchar)+''' else (count(*)/'''+CAST(@PageSize as varchar)+''')+1 end as TtlPage from #t2IDL'+CHAR(9)+CHAR(13)


set @sql=@sql+'  if(object_id(''tempdb..#t1'') is not null) drop table #t1  '+CHAR(9)+CHAR(13)
set @sql=@sql+' if(object_id(''tempdb..#t2'') is not null) drop table #t2'+CHAR(9)+CHAR(13)
set @sql=@sql+' if(object_id(''tempdb..#tIDL'') is not null) drop table #tIDL'+CHAR(9)+CHAR(13)
set @sql=@sql+' if(object_id(''tempdb..#tIDL'') is not null) drop table #tIDL'+CHAR(9)+CHAR(13)




print @sql
exec(@sql) 
end
go

