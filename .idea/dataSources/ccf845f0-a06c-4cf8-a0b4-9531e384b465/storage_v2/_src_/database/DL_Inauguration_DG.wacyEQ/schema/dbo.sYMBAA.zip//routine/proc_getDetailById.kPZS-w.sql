CREATE procedure [dbo].[proc_getDetailById](
@id varchar(100)
)
as 
begin
--DL 相关表
select identityNo,name,gender,birthday,marriage,household,phoneNumber,province,
       address, ApplyChannel,Propaganda,education,school,certificate,entranceDate,graduationDate,area 
from Employee 
where ID=@id

select name,relationship,gender,occupation,phoneNumber,address
from Families 
where ParentId=@id

select name,relationship,department,phoneNumber,empNo,remark
from RelativesInCompany 
where ParentId=@id

select name,relationship,phoneNumber,address
from Linkman
where ParentId=@id

select company,occupation,reasonForLeaving,salary,employmentDate,resignationDate
from WorkExperience
where ParentId=@id

--IDL 相关表
select identityNo,name,engName,email,gender,birthday,stature,weight,marriage,nationality,phoneNumber,province,
       address,applyChannel,Language,Languagelevel,PliticsStatus,area
from Employee_IDL
where ID=@id

--select Education,Degree,StudyMode,education,school,Subject,certificate,entranceDate,graduationDate
--from Education_IDL
--where ParentId=@id

--select job,company,manager,salary,reason,employmentDate,resignationDate
--from WorkExperience_IDL
--where ParentId=@id

select top 1 degree,studyMode,education,school,subject,certificate,entranceDate,graduationDate
from Education_IDL
where ParentId=@id order by DetailId desc

select top 1 job,company,manager,salary,reason,employmentDate,resignationDate
from WorkExperience_IDL
where ParentId=@id order by DetailId desc


select workExperience,hobbies,position,salary
from ExpectWork_IDL
where ParentId=@id

select number,license,unit,startDate,endDate,hour
from License_IDL
where ParentId=@id

select  name,relationship,gender,occupation,phoneNumber,address,bornDate
from Families_IDL
where ParentId=@id

select  name,relationship,phoneNumber,address
from Linkman_IDL
where ParentId=@id

select  name,occupation,phoneNumber,address
from friend_IDL
where ParentId=@id

end
go

