CREATE procedure [dbo].[proc_getInaugrationDetails](
@id varchar(100)
)
as 
begin
--DL
SELECT
	a.ID,
	IdentityNo,
	NAME,
CASE
	WHEN Gender = '1' THEN
	'男' ELSE '女' 
	END AS Gender,
	BirthDay,
CASE
	WHEN Marriage = '1' THEN
	'已婚' ELSE '未婚' 
	END AS Marriage,
CASE
	WHEN Household = '1' THEN
	'非農業' ELSE '農業' 
	END Household,
	PhoneNumber,
	Province,
	Address,
	b.EduName AS Education,
	School,
CASE
	WHEN Certificate = '1' THEN
	'肄業' ELSE '畢業' 
	END Certificate,
	d.attribute_value AS ApplyChannel,
	c.Propaganda,
	EntranceDate,
	GraduationDate,
	CASE WHEN IsReligiousBelief = '0' THEN N'无' 
	 WHEN IsReligiousBelief = '1' THEN N'有' 
	ELSE '' END IsReligiousBelief,
	CASE WHEN ReligiousBelief = '1' THEN N'佛教' 
	 WHEN ReligiousBelief = '2' THEN N'伊斯兰教'
	 WHEN ReligiousBelief = '3' THEN N'基督教'
	 WHEN ReligiousBelief = '4' THEN N'天主教'
	END ReligiousBelief
FROM
	dbo.Employee AS a,
	Sys_Education AS b,
	Sys_Propaganda c,
	Channel_Dictionary d 
WHERE
	a.ID = @id
	AND a.Education = b.EduNo 
	AND a.Propaganda = c.PropagandaID 
	AND
CASE
	WHEN Len ( ISNULL( a.ApplyChannel, 0 ) ) = 3 THEN
	RIGHT ( a.ApplyChannel, 2 ) ELSE ISNULL( a.ApplyChannel, 0 ) 
	END = ISNULL( d.attribute_key, 0 ) 
	AND ISNULL( a.Propaganda, 0 ) = ISNULL( c.PropagandaID, 0 )


select Name,b.RelName as Relationship,Occupation,PhoneNumber,Address 
from dbo.Families as a,Sys_Relationship as b 
where ParentId=@id and a.Relationship=b.RelNo

select Name,b.RelName as Relationship,Department,PhoneNumber,EmpNo,Remark 
from dbo.RelativesInCompany as a,Sys_Relationship as b 
where ParentId=@id and a.Relationship=b.RelNo

select Name,b.RelName as Relationship,PhoneNumber,Address
from dbo.Linkman as a,Sys_Relationship as b  
where ParentId=@id and a.Relationship=b.RelNo

select Company,Occupation,ReasonForLeaving,Salary,EmploymentDate,ResignationDate 
from dbo.WorkExperience where ParentId=@id

select b.EmpNo From Employee as a,HREntryForEmpNo as b where a.IdentityNo=b.IdentityNo
and a.ID=@id

SELECT
	IdentityNo,
CASE
	WHEN IsVaccination = '1' THEN
	'是' ELSE '否' 
	END AS IsVaccination,
	dbo.func_vaccine_manufacturer_conversion ( Vaccination1 ) AS Vaccination1,
CASE
		WHEN datediff( DAY, CAST ( '1900-01-01' AS datetime ), Vaccination1Date ) = 0 THEN
		NULL ELSE Vaccination1Date 
	END AS Vaccination1Date,
	dbo.func_vaccine_manufacturer_conversion ( Vaccination2 ) AS Vaccination2,
CASE
		WHEN datediff( DAY, CAST ( '1900-01-01' AS datetime ), Vaccination2Date ) = 0 THEN
		NULL ELSE Vaccination2Date 
	END AS Vaccination2Date,
	dbo.func_vaccine_manufacturer_conversion ( Vaccination3 ) AS Vaccination3,
CASE
		WHEN datediff( DAY, CAST ( '1900-01-01' AS datetime ), Vaccination3Date ) = 0 THEN
		NULL ELSE Vaccination3Date 
	END AS Vaccination3Date,
	Remark,
	UpdateTime 
FROM
Vaccine where ParentId=@id

--IDL

select IdentityNo,Name,EngName, Email,case when Gender='1' then '男' else '女' end as Gender,BirthDay,
       case when Marriage='1' then '已婚' else '未婚' end as Marriage,Nationality,Stature,Weight,
	   b.Language,c.LanguageLevel,
       PhoneNumber,Province,Address
from dbo.Employee_IDL  as a,Sys_Language as b,Sys_languageLevel as c
where a.ID=@id and a.Language=b.LanguageID  and a.Languagelevel=c.LanguageLevelID




select b.EduName as Education,School,Subject,EntranceDate,GraduationDate
From  Education_IDL as  a ,Sys_Education as b 
where ParentId=@id and a.Education=b.EduNo 


select Name,b.RelName as Relationship,Occupation,PhoneNumber,Address 
from dbo.Families_IDL as a,Sys_Relationship as b 
where ParentId=@id and a.Relationship=b.RelNo

select Name,b.RelName as Relationship,Department,PhoneNumber,EmpNo,Remark
from dbo.RelativesInCompany_IDL as a,Sys_Relationship as b 
where ParentId=@id and a.Relationship=b.RelNo

select Name,Occupation,Address,PhoneNumber
from dbo.Friend_IDL 
where ParentId=@id 


select Name,b.RelName as Relationship,PhoneNumber,Address
from dbo.Linkman_IDL as a,Sys_Relationship as b  
where ParentId=@id and a.Relationship=b.RelNo


select Company,Job,Manager,Reason,Salary,EmploymentDate,ResignationDate 
from dbo.WorkExperience_IDL where ParentId=@id


select  Number,License,Unit,StartDate,EndDate,Hour
from  License_IDL where  ParentId=@id


select WorkExperience,Hobbies,Position,Salary 
from  ExpectWork_IDL  where ParentId=@id


select b.EmpNo From Employee_IDL as a ,HREntryForEmpNo as b where a.IdentityNo=b.IdentityNo
and a.ID=@id

/*EmpNoIDL*/
SELECT
	IdentityNo,
CASE
	WHEN IsVaccination = '1' THEN
	'是' ELSE '否' 
	END AS IsVaccination,
	dbo.func_vaccine_manufacturer_conversion ( Vaccination1 ) AS Vaccination1,
CASE
		WHEN datediff( DAY, cast( '1900-01-01' AS datetime ), Vaccination1Date ) = 0 THEN
		NULL ELSE Vaccination1Date 
	END AS Vaccination1Date,
	dbo.func_vaccine_manufacturer_conversion ( Vaccination2 ) AS Vaccination2,
CASE
		WHEN datediff( DAY, cast( '1900-01-01' AS datetime ), Vaccination2Date ) = 0 THEN
		NULL ELSE Vaccination2Date 
	END AS Vaccination2Date,
	dbo.func_vaccine_manufacturer_conversion ( Vaccination3 ) AS Vaccination3,
CASE
		WHEN datediff( DAY, cast( '1900-01-01' AS datetime ), Vaccination3Date ) = 0 THEN
		NULL ELSE Vaccination3Date 
	END AS Vaccination3Date,
	Remark,
	UpdateTime 
FROM
Vaccine_IDL where ParentId=@id


end
go

