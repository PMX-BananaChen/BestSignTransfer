CREATE FUNCTION [dbo].[func_vaccine_manufacturer_conversion](@vaccine varchar(8)) 
RETURNS nvarchar(50)
as
BEGIN
	declare @result_name nvarchar(50)
	select 
	@result_name = CASE
		WHEN @vaccine = '01' THEN
		N'北京生物(成都生物、兰州生物、长春生物、武汉生物)' 
		WHEN @vaccine = '02' THEN
		N'北京科兴' 
		WHEN @vaccine = '07' THEN
		N'智飞生物' 
		WHEN @vaccine = '08' THEN
		N'康希诺' 
		else
		N''
	END 
  RETURN  @result_name
END;
go

