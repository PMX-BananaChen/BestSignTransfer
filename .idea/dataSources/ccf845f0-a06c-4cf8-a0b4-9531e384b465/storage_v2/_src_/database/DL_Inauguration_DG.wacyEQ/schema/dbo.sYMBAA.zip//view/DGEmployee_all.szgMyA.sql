
CREATE view [dbo].[DGEmployee_all]
as 
select IdentityNo,WechatNo from [dbo].[Employee]
where isnull(WechatNo,'')!=''
union all
select IdentityNo,WechatNo from [dbo].[Employee_IDL]
where isnull(WechatNo,'')!=''
go

